# AzureQueueManagement
For Course Application Development 3

Showing Queue Management In Azure:

1) This application demonstrates how to interact with Azure Queues.
2) The application provides code to peek a message from a queue, to insert a message into a queue and to get the length of a queue.
